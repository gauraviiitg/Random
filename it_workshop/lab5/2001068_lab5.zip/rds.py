import boto3

AWS_REGION = 'ap-south-1' 


DB_INSTANCE_IDENTIFIER = "db-4h2g8j1k"
DB_NAME = "feedbacks"
DB_USER = 'a3f5z1y8'
DB_PASS = 'b8x9c2v4b1n5m6z0'
DB_ENGINE = "mysql"
DB_INSTANCE_CLASS = "db.t2.micro"


rds = boto3.client('rds', region_name=AWS_REGION)


response = rds.create_db_instance(
    DBName='feedbacks',
    DBInstanceIdentifier='feedback-db-4h2g8j1k',
    AllocatedStorage=20,  # 20 GB
    DBInstanceClass='db.t2.micro',
    Engine='mysql',
    MasterUsername='u4j2g7s1',
    MasterUserPassword='p3t6k9v4l2r5',
    PubliclyAccessible=True,
    VpcSecurityGroupIds=['vpc-0a0990dd9745fe179']
)

print(response)


