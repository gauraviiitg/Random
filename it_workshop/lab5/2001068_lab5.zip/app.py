from flask import Flask, request, render_template
import pymysql

app = Flask(__name__)

DB_HOST = 'k3h7q8p5v1rds9876.rds.amazonaws.com'
DB_USER = 'a3f5z1y8'
DB_PASS = 'b8x9c2v4b1n5m6z0'
DB_NAME = 'dbq4w3e7r8'


@app.route('/', methods=['GET', 'POST'])
def feedback():
    messages = []
    if request.method == 'POST':
        message = request.form.get('message')
        connection = pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASS, db=DB_NAME)
        with connection.cursor() as cursor:
            cursor.execute('INSERT INTO feedback (message) VALUES (%s)', (message,))
            connection.commit()
            cursor.execute('SELECT message FROM feedback')
            messages = [row[0] for row in cursor.fetchall()]
        connection.close()
    return render_template('feedback.html', messages=messages)

if __name__ == '__main__':
    app.run(debug=True)
